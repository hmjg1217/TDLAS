  % This is the sub-program to simulate the lineshape function of TDLAS.
function PhiV = vvoigtshape(par,niu);
A = [-1.2150 -1.3509 -1.2150 -1.3509];    B = [ 1.2359  0.3786 -1.2359 -0.3786];
C = [-0.3085  0.5906 -0.3085  0.5906];    D = [ 0.0210 -1.1858 -0.0210  1.1858];
nniu0 = par(1);  SS = par(2);   ddeltaG = par(3);   ddeltaL = par(4);
nniu = niu; ddeltaair = 0; 
        
PhiG = 2./ddeltaG*sqrt(log(2)/pi);    a = ddeltaL./ddeltaG*sqrt(log(2));
y = 2*sqrt(log(2))*(nniu-nniu0-ddeltaair);    PPhiV = y*0;
    for k = 1:4
        PPhiV = PPhiV + PhiG.*(C(k).*(a-A(k))+D(k)*(y./ddeltaG-B(k)))./((a-A(k)).^2+(y./ddeltaG-B(k)).^2);
    end
PhiV = PPhiV.*SS;
